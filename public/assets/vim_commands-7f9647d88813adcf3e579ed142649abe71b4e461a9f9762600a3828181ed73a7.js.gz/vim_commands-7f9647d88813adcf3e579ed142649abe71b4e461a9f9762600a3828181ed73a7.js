function getIds(var ids){
	console.log("hello");
	// console.log("ids: " + ids);
} 


function myFunction(){
	alert("hello");
}


$(document).ready(function() {
	console.log("ready!");
	alert("ready!");
});

